<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @var $property_bathrooms
 */
?>
<span class="g5ere__loop-property-bathrooms"><?php echo sprintf(esc_html__('%s Ba','g5-ere'),$property_bathrooms)?></span>
